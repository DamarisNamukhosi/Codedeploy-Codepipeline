<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "root", "hospital");

// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

// Escape user inputs for security
$firstname = mysqli_real_escape_string($link, $_POST['firstname']);
$surname = mysqli_real_escape_string($link, $_POST['surname']);
$password = mysqli_real_escape_string($link, $_POST['password']);
$password2 = mysqli_real_escape_string($link, $_POST['password2']);

if ($password != $password2) {
echo ("<script language='javascript'>

window.alert('Passwords dont match')

window.location.href='patient.php';

echo </script>");

exit;
}

else
// attempt insert query execution
$sql = "INSERT INTO patients (firstname, surname, password) VALUES ('$firstname', '$surname', '$password')";
if(mysqli_query($link, $sql)){
    echo ("<script language='javascript'>

window.alert('Account created successfully. Proceed to login')

window.location.href='patient.php';

echo </script>");
exit;
} else{
    echo "ERROR: Could not execute to $sql. " . mysqli_error($link);
}

// close connection
mysqli_close($link);
?>
